# Gap Analysis of the Pāṇinian Self-Assimilating Foundation Model

## Impact of Expanding the Design from a Dhātu-Centred Model to a Full Sanskrit Structural Stack

**Document reviewed:** `Paninian_Self_Assimilating_Model.md`  
**Purpose:** Identify what changes, what remains valid, and what is missing after recognizing that the computational opportunity in Sanskrit extends far beyond dhātus and derivational morphology.  
**Status:** Research gap analysis; not yet a revised architecture specification.  
**Date:** August 2026

---

# Executive Conclusion

The current self-assimilating-model document contains a strong conceptual core:

- internal structure generates hypotheses;
- external evidence grounds or corrects those hypotheses;
- new knowledge enters through reversible, governed adaptation rather than uncontrolled weight rewriting;
- grammatical plausibility, semantic interpretation, and empirical support are kept conceptually separate;
- provenance, contradiction, rollback, and institutional consolidation are treated as architectural requirements.

Those ideas remain valuable.

However, the document is structurally **too dhātu- and derivation-centric**. It treats the model’s inward-looking organization principally as a root-addressed memory with derivational families. Once Sanskrit is understood as a multilayer system involving phonology, Sandhi, inflection, derivation, compounds, kāraka–vibhakti relations, sentence-level compatibility, lexical conventionalization, discourse, register, accent, and rule-scope mechanisms, several parts of the design become incomplete.

The principal impact is this:

> The project can no longer be adequately described as a model that retrieves through dhātus and aligns external evidence to derivational families. It must become a model that performs **cross-layer constraint intersection over a typed Sanskrit structural stack**, while preserving a language-independent concept and evidence layer.

This expanded understanding strengthens the possible scientific contribution, but it also raises the standard of proof. A full Sanskrit structural system cannot fairly be compared only with a generic semantic graph. It must be compared with:

1. an information-equivalent universal linguistic stack;
2. a strong generic semantic graph;
3. a generic executable grammar with scope, inheritance, defaults, exceptions, and rule ordering;
4. a learned neural latent structure;
5. text-only and vector-memory controls.

The current document should therefore be treated as a **conceptual precursor**, not yet a complete research architecture.

---

# 1. What Changed After the Expanded Understanding of Sanskrit

## 1.1 The internal address is no longer the dhātu alone

The current document proposes a dhātu-addressed internal memory in which roots connect to semantic tendencies, derivations, compounds, roles, domain senses, and evidence. That is useful, but it is only one index.

A complete Sanskrit-native memory requires several simultaneous addresses:

```text
surface form
phonological form
Sandhi analysis
canonical pada or lemma
inflectional paradigm
prātipadika or dhātu
upasarga and derivational operation
compound hierarchy and vigraha
kāraka and event role
sentence interpretation
lexical sense
register and domain
discourse referent
concept identifier
evidence record
```

A query may need to enter through any one of these and reach the same concept through a different path.

## 1.2 “Derivational memory” becomes a multilayer structural memory

The four-memory taxonomy in the current document—parametric, derivational, evidential, and plastic—remains useful, but “derivational memory” is too narrow. It should become a **Sanskrit Structural Memory** containing at least:

- phonological and orthographic equivalence;
- Sandhi transformations and segmentation alternatives;
- inflectional paradigms;
- derivational procedures;
- compound structure;
- predicate-centred semantic relations;
- sentence-level constraints;
- lexicalized and conventional senses;
- discourse and coreference;
- register, period, and domain;
- rule scope, inheritance, exceptions, precedence, and optionality.

## 1.3 Assimilation becomes cross-layer reconciliation

The current Assimilation Compiler maps external claims to concepts, dhātus, derivations, provenance, contradictions, and proposed memory changes.

The expanded compiler must answer additional questions:

- Which script and canonical phonological form correspond to the source term?
- Does the source term have one or several Sanskrit lexical candidates?
- Is the proposed expression an inflection, a derivation, a compound, a conventional label, or an unanalyzable atomic term?
- Which event roles and participant relations does the source assert?
- Which sentence-level interpretation is intended?
- Does the term have a different established sense in another domain or historical register?
- Which related forms should inherit the update?
- Which forms must be protected as lexicalized exceptions?
- What part of the interpretation comes from Sanskrit structure, and what part comes only from external evidence?

## 1.4 Update locality becomes a multilayer scope problem

The current document describes “semantic inheritance with override.” The expanded view shows that update scope must be defined independently across several layers:

```text
surface equivalence
inflectional equivalence
derivational inheritance
compound inheritance
event-role equivalence
discourse coreference
domain and register scope
temporal validity
evidential status
```

An update may propagate across one layer but be blocked at another.

Example:

- It should propagate across a word’s case forms.
- It may propagate to a derived agent noun.
- It may not propagate to a lexicalized compound.
- It may apply in modern computer science but not in a classical philosophical usage.
- It may be grammatically plausible but remain empirically unsupported.

## 1.5 The project’s novelty claim changes

The strongest potential novelty is no longer:

> dhātu-addressed self-assimilation.

It becomes:

> **A model that uses an executable, multilayer Sanskrit structural system to constrain interpretation, generate knowledge-gap queries, govern inheritance and exceptions, and define the scope of reversible knowledge updates.**

This is a stronger research thesis, but only if the contribution survives information-equivalent universal and procedural baselines.

---

# 2. What the Current Document Gets Right and Should Retain

The following elements remain sound and should be preserved in the revision.

## 2.1 Intensional prior versus referential grounding

The document correctly states that morphological or derivational structure can generate a provisional interpretation but cannot establish scientific or real-world truth. External documents, equations, observations, code, and tools remain necessary.

## 2.2 Explicit internal memory beside model weights

The document correctly rejects the notion that transformer weights can be queried like a clean root-indexed database. An explicit, inspectable memory is necessary.

## 2.3 Reconfiguration before permanent rewriting

The principle “rewire at the edge; consolidate at the centre” remains appropriate. Routing, writable memory, and temporary adapters should precede permanent base-weight changes.

## 2.4 Two-way correction

The document correctly permits external evidence to override literal derivation, establish a conventional technical meaning, split a concept into domain senses, or show that a structurally plausible claim is false.

## 2.5 Provenance and contradiction

The insistence on retaining original sources, evidence quality, contradictions, dates, and review states remains essential.

## 2.6 Multi-speed learning

Token-time, session-time, institutional-memory, and release-time learning remain a useful governance architecture.

## 2.7 Explicit failure modes

The risks already identified—etymological fallacy, circular self-confirmation, forcing reality into morphology, catastrophic drift, poisoning, and loss of reproducibility—remain valid. They need expansion rather than replacement.

---

# 3. Severity Scale Used in This Gap Register

| Severity | Meaning |
|---|---|
| **Critical** | The central scientific claim or controlled evaluation is invalid or materially incomplete without resolving the gap. |
| **High** | The architecture may work only in narrow demonstrations or fail in natural Sanskrit without resolving the gap. |
| **Medium** | Important for coverage, specialist domains, robustness, or institutional completeness, but not necessarily required in the first pilot. |
| **Later-specialist** | Valuable for full Sanskrit coverage but should be staged after the core modern/classical research model is validated. |

---

# 4. Consolidated Gap Register

| ID | Gap | Severity | Immediate consequence |
|---|---|---:|---|
| G-01 | “Pāṇinian” is used as an umbrella for structures drawn from several Sanskrit intellectual traditions | Critical | Intellectual attribution and architecture boundaries are unclear |
| G-02 | The model is dhātu-centred rather than multilayer | Critical | Retrieval and update scope are incomplete |
| G-03 | No bounded definition of the intended “Sanskrit structural stack” | Critical | The project cannot be implemented or evaluated reproducibly |
| G-04 | No explicit phonology, varṇa-class, script, or transliteration layer | High | Surface variation and cross-script identity remain fragmented |
| G-05 | Sandhi is not modelled as a bidirectional probabilistic transformation and segmentation lattice | Critical | The model cannot reliably connect surface text to underlying lexical structure |
| G-06 | Inflectional paradigms are absent from memory and update scope | Critical | Knowledge does not reliably propagate across subanta and tiṅanta forms |
| G-07 | Derivation is narrower than Sanskrit derivational morphology | High | kṛt, taddhita, sanādi, feminine, causative, desiderative, and related structures are underrepresented |
| G-08 | Samāsa is not represented as a nested, probabilistic semantic structure with vigraha and lexicalization | Critical | Compound interpretation and inheritance will be unreliable |
| G-09 | Kāraka and vibhakti are not separated formally | Critical | Event identity and role-equivalent paraphrases cannot govern updates accurately |
| G-10 | Sentence-level verbal-cognition constraints are missing | High | The model lacks explicit expectancy, compatibility, proximity, and intended-purport checks |
| G-11 | Lexical sense, rūḍhi/yogarūḍhi, polysemy, metaphor, and idiom are under-specified | Critical | The model will over-propagate literal derivations |
| G-12 | Discourse, anaphora, ellipsis, and śāstric discourse structure are missing | High | Long-document assimilation and cross-sentence update propagation are incomplete |
| G-13 | Register, period, genre, and domain are not first-class scope controls | Critical | Modern updates may contaminate Vedic, classical, poetic, or domain-specific senses |
| G-14 | Svara, Vedic morphology, and recensional variation are absent | Later-specialist | Vedic processing cannot be treated as an extension of Classical Sanskrit |
| G-15 | Chandas, oral preservation, and constrained literary form are absent | Later-specialist | Poetry, recitation, and textual validation remain outside the model |
| G-16 | The model lacks an explicit rule/meta-rule graph | Critical | Adhikāra, anuvṛtti, defaults, exceptions, precedence, optionality, and asiddha-like isolation cannot guide updates |
| G-17 | The architecture uses a flat or loosely structured graph where a typed multilayer hypergraph is needed | Critical | Cross-layer constraints and alternative analyses cannot be represented cleanly |
| G-18 | There is no canonical language-independent concept layer | Critical | Reality may be forced into Sanskrit morphology, and comparisons become unfair |
| G-19 | “Looking inward” uses one primary address instead of multi-index structural retrieval | High | Queries through inflection, compound, role, discourse, or sense may fail |
| G-20 | The Assimilation Compiler lacks cross-layer compilation semantics | Critical | External evidence cannot be aligned safely or reversibly |
| G-21 | Memory types are too coarse | High | Different update and retention rules cannot be assigned to different linguistic structures |
| G-22 | Update scope is not defined as a layer-wise lattice | Critical | Propagation and locality cannot be measured correctly |
| G-23 | Default–exception and inheritance semantics are informal | Critical | “Semantic inheritance with override” is not executable |
| G-24 | Conflicting analyses, schools, dictionaries, and domain conventions have no adjudication model | High | The model may collapse legitimate alternatives into one institutional answer |
| G-25 | Tri-axial confidence is too coarse | High | A single grammatical score hides segmentation, morphology, compound, role, discourse, and lexical uncertainties |
| G-26 | Confidence propagation and calibration are undefined | High | Output confidence may be numerically impressive but epistemically meaningless |
| G-27 | No abstention or ambiguity-preserving response protocol is specified | High | The system may select one interpretation when several should remain live |
| G-28 | Required annotation and corpus schema are absent | Critical | The model cannot be trained or independently reproduced |
| G-29 | Expert disagreement and annotation governance are not designed | Critical | Gold data quality and institutional legitimacy are at risk |
| G-30 | Synthetic Sanskritization can create circular terminology and translation artifacts | Critical | The model may validate language it generated itself |
| G-31 | The research conditions A–E conflate structure, retrieval, memory, and plasticity | Critical | A positive or negative result will not identify the causal mechanism |
| G-32 | The generic semantic graph baseline is no longer adequate | Critical | The Sanskrit stack may win merely because it contains more information and procedures |
| G-33 | No structural ladder or leave-one-layer-out ablation is specified | Critical | The contribution of individual Sanskrit elements cannot be measured |
| G-34 | Information, capacity, and compute equivalence are not formalized | Critical | Any claimed advantage may be a resource imbalance |
| G-35 | Oracle versus automatically predicted structure is not separated | High | Linguistic theory and tool quality will be confounded |
| G-36 | Holdouts do not yet cover all structural layers | High | The model may memorize families, senses, registers, or discourse patterns |
| G-37 | Natural, engineered-technical, and clean-room fictional evaluations are not separated | Critical | Results may reflect terminology engineering or pretraining leakage |
| G-38 | Propagation–locality evaluation is not multilayer | Critical | The project’s strongest novelty cannot be measured |
| G-39 | Dynamic fast-weight rewiring is premature | High | Complexity and forgetting may be introduced before structured memory is validated |
| G-40 | The effective-weight equation does not specify scope generation or conflict isolation | High | “Rewiring” remains a metaphor rather than an algorithm |
| G-41 | Parser errors can cascade across layers, but error containment is absent | High | One wrong split may corrupt morphology, roles, concepts, and updates |
| G-42 | Graph growth, latency, storage, and caching are under-specified | High | The architecture may not scale beyond demonstration size |
| G-43 | Existing Sanskrit tools lack a common interoperability representation | Critical | The institution cannot integrate them reproducibly |
| G-44 | Explanatory traces are not proven causal | High | The system may display a Sanskrit analysis while answering from unrelated neural memory |
| G-45 | Institutional governance lacks representation-specific expert roles | Critical | No single panel can validate grammar, verbal cognition, Vedic material, discourse, and modern science |
| G-46 | The uniqueness statement is broader than the demonstrated algorithmic core | Critical | Funding reviewers may classify it as integration rather than research novelty |
| G-47 | No explicit falsification and stopping criteria are attached to the expanded hypothesis | Critical | The programme may continue scaling despite negative evidence |

---

# 5. Detailed Gap Analysis

## 5.1 Conceptual and Attribution Gaps

### G-01 — “Pāṇinian” is overextended

**Observation in the current document:** Phonology, morphology, semantics, evidence, discourse-like interpretation, and update governance are discussed under one Pāṇinian umbrella.

**Gap:** Several relevant computational ideas belong to distinct traditions or later developments, including phonetic and accent traditions, Nirukta and lexicography, theories of verbal cognition, discourse frameworks, and śāstric organizational devices. A Pāṇinian grammatical core is central, but the full stack is not reducible to the Aṣṭādhyāyī alone.

**Impact:**

- intellectual attribution becomes inaccurate;
- the architecture has no clear ownership boundary;
- the expert consortium cannot be staffed correctly;
- reviewers may challenge the proposal for treating heterogeneous traditions as one system.

**Required correction:** Define a layered attribution model:

```text
Pāṇinian grammatical core
Śikṣā/Prātiśākhya-informed phonology and accent
Nirukta/lexicographic sense layer
Śābdabodha/verbal-cognition sentence layer
Tantrayukti and discourse layer
Chandas/prosody specialist layer
Modern concept and evidence layer
```

A safer project name may be **Sanskrit Structural Self-Assimilating Foundation Model**, with a Pāṇinian core, rather than implying that every component is directly Pāṇinian.

### G-02 — Dhātu-centred framing is too narrow

**Observation:** The current memory and deliverables repeatedly use “dhātu-addressed” as the central organizing principle.

**Gap:** Many valid retrieval and update paths do not begin with a dhātu:

- nominal stems;
- indeclinables;
- inflected forms;
- compounds;
- event roles;
- lexicalized senses;
- pronouns and discourse references;
- modern atomic concept identifiers;
- borrowed or conventionally defined terminology.

**Required correction:** Replace a single dhātu address with a **multi-index structural address system**.

### G-03 — “All elements of Sanskrit” has no bounded research definition

**Gap:** Sanskrit is too broad to operationalize as one undifferentiated object. The project needs a declared first-release scope.

**Required correction:** Define a Version 1 structural coverage contract, for example:

- Classical and contemporary prose first;
- phonology, Sandhi, morphology, compounds, kāraka, lexical sense, and sentence relations included;
- discourse included for selected śāstric texts;
- Vedic accent and Chandas staged as specialist extensions;
- poetry and alaṅkāra treated as later modules.

Without this, “complete Sanskrit” becomes unfalsifiable.

---

## 5.2 Missing Linguistic Layers

### G-04 — No phonological and script-normalization substrate

The current model begins from surface text but does not define a canonical representation across Devanāgarī, Roman transliteration, other scripts, OCR noise, or speech-derived forms.

**Required addition:**

- canonical phonological form;
- script adapters;
- varṇa features;
- pratyāhāra or sound-class features where empirically useful;
- Unicode normalization;
- transliteration provenance;
- cross-script identity links.

### G-05 — Sandhi is not a full probabilistic lattice

The current document mentions linguistic structure but does not make Sandhi an independent memory and inference layer.

Sanskrit word segmentation can yield multiple valid surface analyses, and contextual semantics is required to rank them. The architecture must retain alternatives rather than committing prematurely. See Krishna et al., *Word Segmentation in Sanskrit Using Path Constrained Random Walks*.

**Required addition:**

```text
surface string
→ candidate boundary sets
→ candidate canonical forms
→ morphological compatibility
→ sentence compatibility
→ contextual ranking
```

**Research implication:** A wrong Sandhi decision must not silently become a permanent concept update.

### G-06 — Inflectional paradigms are absent

The document discusses derivation, but knowledge propagation across nominal and verbal paradigms is not formalized.

**Required addition:**

- subanta features: stem, gender, case, number;
- tiṅanta features: root, class, person, number, tense/mood, voice, pada;
- paradigm identity;
- syncretism and ambiguity;
- irregular and exceptional forms.

**Why it matters:** Inflectional propagation is one of the cleanest tests of update scope: all valid forms of one lexeme should inherit the concept, while similar endings on unrelated forms should not.

### G-07 — Derivational morphology is under-specified

The current document focuses on roots, prefixes, and general derivational families. It does not distinguish the semantics and rule behaviour of:

- kṛt derivatives;
- taddhita derivatives;
- sanādi formations;
- causatives;
- desideratives;
- intensives;
- feminine derivation;
- nominal-base derivation;
- multiple derivational paths to the same surface form.

The taddhita system is especially relevant because recent computational work describes hierarchical inheritance, semantic scope, defaults, exceptions, and conflict resolution. See Ayachit et al., *Computational Modelling of the Apatyādhikāra in Aṣṭādhyāyī*.

### G-08 — Samāsa lacks nested structure and lexicalization

The document treats compounds as part of derivational memory but does not define:

- nested constituent spans;
- semantic head;
- vigraha;
- compound-type alternatives;
- exocentricity;
- context-dependent relation selection;
- lexicalized compounds;
- domain-specific conventional meanings.

Multi-component compounds require hierarchical interpretation, and context materially affects semantic relation identification. See Sandhan et al., *DepNeCTI*.

**Required correction:** Represent samāsa as a probabilistic compound hypergraph, not a flat list of components.

### G-09 — Kāraka and vibhakti are not formally separated

The document mentions kāraka relations but does not model the mapping between:

- surface case/inflectional realization;
- predicate-centred participant relation;
- voice and tense/aspect/mood;
- omitted or transformed arguments.

**Impact:** The model cannot reliably identify that active, passive, nominalized, and reordered expressions may describe the same event.

### G-10 — Sentence-level interpretation constraints are missing

The document’s “internal hypothesis” lacks an explicit mechanism for sentence-level constraints such as:

- expectancy or unsatisfied argument requirements;
- semantic compatibility;
- proximity/connectedness;
- intended purport;
- ellipsis recovery;
- multiple plausible dependency assignments.

Sanskrit dependency research explicitly notes the role of expectancy, congruence of word meanings, proximity, ellipsis, and alternative morphological analyses. See Kulkarni et al., *Dependency Relations for Sanskrit Parsing and Treebank*.

### G-11 — Lexical conventionalization is not a full memory layer

The current “semantic inheritance with override” section recognizes lexicalization in principle but does not provide a machine-usable sense architecture.

**Required addition:**

- sense IDs;
- literal derivational interpretation;
- attested conventional sense;
- domain sense;
- historical sense;
- metaphorical/idiomatic sense;
- disputed analysis;
- corpus attestations;
- dictionary provenance;
- inheritance-blocking status.

Recent Sanskrit research is still building machine-usable sense inventories, which demonstrates that this resource cannot be assumed to exist already. See Pradeep et al., *Towards Building a Computational Sense Inventory from the Monier-Williams Dictionary*.

### G-12 — Discourse and inter-sentential reasoning are absent

The current model can assimilate documents, but its internal structure remains primarily word-, concept-, and claim-centred.

**Missing capabilities:**

- anaphora and coreference;
- ellipsis across sentences;
- quotation and attributed speech;
- cause, contrast, concession, example, objection, response, and conclusion;
- topic continuity;
- śāstric organizational devices;
- paragraph and section coherence.

TantraTagger demonstrates that Sanskrit śāstric discourse has structures not captured by sentence-level analysis alone.

### G-13 — Register, period, genre, and domain are not structural boundaries

The current evidential memory stores domain and temporal scope, but register and historical stage do not govern linguistic interpretation and update propagation.

**Required addition:**

```text
Vedic
Epic
Classical
śāstric technical
poetic
commentarial
contemporary Sanskrit
engineered scientific Sanskrit
```

Vedic and Classical Sanskrit differ in phonology, accent, grammar, vocabulary, and usage; they cannot safely share one unqualified grammar and sense layer. See Krishnan et al., *Challenges in Processing Vedic Sanskrit*.

### G-14 and G-15 — Vedic accent, recensional variation, Chandas, and oral structure are unplanned

These should not be forced into the first pilot, but the architecture should reserve compatible extension points.

**Required decision:** Explicitly classify them as later specialist modules rather than silently implying complete coverage.

---

## 5.3 Missing Rule and Representation Architecture

### G-16 — No explicit meta-rule and rule-scope graph

This is one of the most important missing pieces.

The current document uses “semantic inheritance with override,” but does not encode the mechanisms needed to make that executable:

- governing scope;
- inherited context;
- general rule versus exception;
- rule precedence;
- optional forms;
- conflicting applicable rules;
- temporary invisibility or isolation of intermediate states;
- control markers that do not appear in surface output.

**Potential machine-learning role:**

| Grammatical idea | Possible update-system role |
|---|---|
| Adhikāra | Scope of a family of memory updates |
| Anuvṛtti | Inherited context shared across descendants |
| Utsarga–apavāda | Default rule plus protected exception |
| Vipratiṣedha/rule precedence | Conflict resolution among updates |
| Optionality | Preserve several admissible outcomes |
| It-marker | Internal control metadata not emitted to users |
| Asiddha-like isolation | Prevent one temporary change from contaminating another stage |

This is an engineering hypothesis, not a claim of direct equivalence. It nonetheless supplies a more distinctive algorithmic centre than root lookup alone.

### G-17 — A flat graph is inadequate

The architecture needs a typed multilayer hypergraph or graph-plus-transducer system.

A compound can connect more than two constituents; a Sandhi operation maps sequences to sequences; a derivation is procedural; an event has multiple participants; evidence can support one sense while contradicting another.

**Required representation:**

```text
phonological graph
surface/lexical graph
inflectional paradigm graph
derivational process graph
compound hypergraph
event/kāraka graph
sentence-constraint graph
discourse graph
lexical-sense graph
concept graph
evidence/provenance graph
rule-control graph
```

### G-18 — No canonical language-independent concept layer

This is a critical safeguard.

A concept must exist independently of whether Sanskrit offers an elegant derivation. The model needs an atomic concept node with definitions, formal relations, equations, code, and evidence. Sanskrit structures should align to the concept; they must not be the sole ontology.

**Without this layer:**

- reality may be forced into morphology;
- translation loss cannot be measured;
- generic baselines cannot receive equivalent information;
- borrowed or newly discovered concepts become awkward exceptions;
- the model may confuse a descriptive name with the concept itself.

### G-19 — Internal retrieval is not multi-index

The system should retrieve through whichever structural path is most informative:

- phonological identity;
- canonical form;
- paradigm;
- derivation;
- compound component;
- event role;
- lexical sense;
- discourse referent;
- concept;
- evidence.

A learned router should choose among indexes and preserve the path that produced the result.

---

## 5.4 Assimilation and Memory Gaps

### G-20 — The Assimilation Compiler is not a true structural compiler

The present compiler output is claim-centred. It must become a multi-stage compiler with explicit intermediate representations.

A revised pipeline should resemble:

```text
source preservation
→ language/script normalization
→ source-faithful semantic parse
→ entity/event extraction
→ concept alignment
→ Sanskrit lexical candidates
→ phonological and Sandhi analysis
→ morphology and derivation
→ compound and sentence analysis
→ register/domain assignment
→ evidence and contradiction analysis
→ inheritance/update-scope proposal
→ human or automated validation
→ reversible memory transaction
```

Each stage must preserve uncertainty and provenance.

### G-21 — Memory taxonomy is too coarse

The “derivational memory” should be divided operationally, even if exposed as one logical store:

- form memory;
- paradigm memory;
- derivation memory;
- compound memory;
- event-role memory;
- lexical-sense memory;
- discourse memory;
- rule/meta-rule memory;
- concept memory;
- evidence memory;
- temporary plastic memory.

Different memories need different update frequencies, confidence thresholds, and rollback policies.

### G-22 — Update scope is not a layer-wise lattice

The document needs a gold and predicted update-scope representation:

```text
Update target
├── surface variants
├── Sandhi variants
├── inflectional forms
├── inheriting derivatives
├── non-inheriting derivatives
├── compound occurrences
├── event-role paraphrases
├── discourse references
├── cross-language equivalents
└── protected boundaries
    ├── homonym
    ├── lexicalized sense
    ├── different domain
    ├── different register
    ├── historical usage
    └── unsupported claim
```

This should become the central object for propagation and locality evaluation.

### G-23 — Inheritance and override remain informal

“Semantic inheritance with override” must be converted into explicit rules or learned functions:

- what is inherited;
- from which parent relation;
- under what domain;
- with what confidence;
- which exception blocks it;
- whether the exception is permanent, temporal, or contextual;
- whether the update propagates to surface forms, concepts, or both.

### G-24 — Legitimate disagreement is not represented

Sanskrit analysis can involve competing segmentations, derivations, lexical senses, grammatical interpretations, dictionaries, traditions, and modern terminology proposals.

**Required addition:**

- alternative analysis sets;
- source and school attribution;
- adjudicated versus unresolved status;
- institution-approved usage distinct from historically attested usage;
- minority or deprecated terminology retained rather than deleted;
- domain-specific coexistence.

---

## 5.5 Confidence and Epistemic Gaps

### G-25 — The three confidence scores are too coarse

The current grammatical, semantic, and evidential confidence separation is conceptually valuable, but “grammatical confidence” compresses too many independent uncertainties.

A richer confidence vector may include:

```text
C_script
C_phonology
C_sandhi_segmentation
C_inflection
C_derivation
C_compound
C_karaka
C_sentence
C_discourse
C_lexical_sense
C_concept_alignment
C_evidence
C_temporal_validity
C_source_reliability
```

The user-facing system may summarize these into three groups, but the internal system needs the finer structure.

### G-26 — Confidence propagation is undefined

The system needs a calibration model for how uncertainty in an early layer affects later conclusions.

Example:

```text
low segmentation confidence
→ multiple morphological analyses
→ multiple compound interpretations
→ divergent concept alignments
→ external retrieval required
```

No simple multiplication or averaging should be assumed without empirical calibration.

### G-27 — No ambiguity-preserving answer protocol

The model must sometimes output:

- two live analyses;
- a dominant interpretation plus a minority interpretation;
- a grammatical analysis without factual commitment;
- a concept answer with an unresolved Sanskrit label;
- an abstention requiring scholar or domain review.

Forced single-answer decoding would undermine the entire uncertainty-aware design.

---

## 5.6 Data, Annotation, and Corpus Gaps

### G-28 — No training-data schema for the expanded stack

The project needs an explicit annotation record such as:

```text
source passage
script and normalization
Sandhi segmentation candidates
canonical forms
morphological features
derivation trace
compound structure
kāraka/dependency graph
sentence constraints
lexical sense IDs
discourse relations
register/domain/time
concept IDs
evidence claims
update-scope labels
provenance and reviewer history
```

Without a schema, the architecture remains conceptual.

### G-29 — Expert disagreement and quality assurance are not designed

A full stack requires several expert groups:

- phonology and Vedic specialists;
- Pāṇinian grammar scholars;
- lexical-semantics and dictionary specialists;
- verbal-cognition and sentence-semantics specialists;
- discourse and śāstra specialists;
- computational linguists;
- modern domain experts;
- data-governance and evaluation teams.

The project needs inter-annotator agreement metrics, disagreement taxonomies, adjudication protocols, and published annotation guidelines.

### G-30 — Synthetic-data circularity is under-addressed

The current rehearsal and Sanskritization loops can create a dangerous cycle:

```text
model coins term
→ model translates using term
→ model reads its translation
→ model treats repeated term as attested evidence
```

**Required safeguards:**

- distinguish generated usage from independent attestation;
- retain source-language evidence;
- prevent model-generated frequency from becoming semantic authority;
- maintain expert-reviewed concept IDs;
- use untouched external test sets;
- run adversarial back-translation and formal validation;
- label synthetic, translated, attested, and institutionally standardized data separately.

---

## 5.7 Experimental Design Gaps

### G-31 — Models A–E conflate too many factors

The current progression from ordinary model to RAG, internal derivation, assimilation, and plastic assimilation changes several variables simultaneously.

A positive Model D result would not reveal whether the gain came from:

- morphology;
- a graph;
- better retrieval;
- more information;
- provenance;
- contradiction handling;
- additional parameters.

**Required correction:** Introduce a structural ladder before the assimilation ladder.

### G-32 — The generic semantic graph is an insufficient baseline

A full Sanskrit stack contains phonological transduction, morphology, procedures, semantic roles, discourse, and rule scope. Comparing it only with a static entity–relation graph would be unfair.

Required controls:

1. generic semantic graph;
2. universal linguistic stack;
3. generic executable grammar;
4. learned latent structure;
5. controlled descriptive English or another morphologically rich language;
6. vector memory;
7. text-only system.

### G-33 — No structural ladder or layer ablation

Suggested cumulative ladder:

```text
S0 text only
S1 phonology + script + Sandhi
S2 inflection
S3 derivation
S4 compounds
S5 kāraka/event roles
S6 sentence constraints
S7 discourse
S8 rule scope/defaults/exceptions
S9 lexical senses/register/evidence
S-Full complete stack
```

Then run full-minus-one-layer ablations.

### G-34 — Information, capacity, and compute equivalence are not formalized

Every condition must receive the same canonical knowledge. The project must match or account for:

- facts and definitions;
- concept relations;
- node and edge budgets;
- graph-encoder parameters;
- retrieval budget;
- context tokens;
- training FLOPs;
- inference FLOPs;
- parser and graph-construction cost;
- latency and memory.

Otherwise the experiment measures resource inequality.

### G-35 — Oracle and predicted structures are not separated

The project should compare:

- scholar-validated structure;
- rule-engine-generated structure;
- neural-predicted structure;
- ensemble structure;
- noisy structure.

Possible interpretation:

- Oracle succeeds, predicted fails: the theory may be sound, tooling is weak.
- Oracle fails: the representational thesis itself is weak.

### G-36 — Holdouts are not comprehensive

Required holdouts include:

- unseen Sandhi environment;
- unseen inflectional cell;
- unseen derivational combination;
- entire derivational family;
- unseen nested compound;
- unseen event-role paraphrase;
- new domain sense;
- lexicalized exception;
- discourse relation;
- historical/register boundary;
- conflicting evidence update.

### G-37 — Evaluation worlds are not separated

Use three evaluation layers:

1. **Clean-room fictional world:** no pretraining leakage; controlled concepts and updates.
2. **Engineered modern technical Sanskrit:** tests terminology and applied reasoning.
3. **Attested natural Sanskrit:** tests ambiguity, lexicalization, genre, and real usage.

A gain only in engineered terminology may show that descriptive naming helps, not that the full Sanskrit architecture is superior.

### G-38 — Propagation and locality are not multilayer

The main novelty test should measure whether the Sanskrit stack moves the propagation–locality Pareto frontier across:

- surface forms;
- inflections;
- derivations;
- compounds;
- event paraphrases;
- discourse references;
- cross-language expressions;

while preserving:

- homonyms;
- lexicalized exceptions;
- unrelated roles;
- other domains;
- other registers;
- unsupported claims.

---

## 5.8 Plasticity and Rewiring Gaps

### G-39 — Fast-weight adaptation is introduced too early

The project should first establish that the structural stack improves retrieval and update scope using external writable memory. Only then should it add dynamic adapters.

Safer order:

```text
structural analysis
→ structured retrieval
→ writable semantic memory
→ routing
→ temporary adapters
→ reviewed consolidation
```

### G-40 — The effective-weight equation is not an implementation

The equation combining base, internal, evidence, and task deltas does not define:

- how each delta is generated;
- which layers it can modify;
- how scope is enforced;
- how conflicting deltas interact;
- how updates expire;
- how rollback is implemented;
- how unrelated capabilities are protected.

A formal adapter-generation and scope-controller specification is needed.

---

## 5.9 Engineering and Interoperability Gaps

### G-41 — No error-containment architecture

One erroneous Sandhi split can cause:

```text
wrong lexical form
→ wrong morphology
→ wrong compound relation
→ wrong event role
→ wrong concept
→ wrong memory update
```

Required controls:

- maintain alternative paths;
- layer-wise confidence thresholds;
- delayed commitment;
- consistency checks;
- external evidence checks;
- rollback of downstream records when an upstream analysis changes.

### G-42 — Scaling costs are unspecified

A full multilayer lattice can grow combinatorially.

The project needs plans for:

- candidate pruning;
- sparse hypergraphs;
- caching;
- morphological and compound memoization;
- graph versioning;
- retrieval-depth limits;
- approximate indexes;
- hot versus archival memory;
- offline versus online analysis;
- latency budgets.

### G-43 — No common interoperability schema

Existing tools return different representations. The institution needs an open interchange format that can encode:

- candidate analyses;
- confidence;
- derivation traces;
- source tool;
- version;
- graph relations;
- human corrections;
- unresolved alternatives.

Without it, the project becomes a collection of brittle adapters.

### G-44 — Explanations may not be causal

A displayed derivation trace can be plausible even when the model ignored it.

Required causal tests:

- remove the structural input;
- corrupt one layer;
- substitute another valid analysis;
- intervene on a relation;
- patch one graph state into another example;
- measure output and confidence changes;
- compare generated trace with actual retrieval and routing logs.

---

## 5.10 Institutional and Scientific-Claim Gaps

### G-45 — Governance is not aligned with the expanded architecture

The institution needs separate boards or working groups for:

- representation standards;
- grammatical and linguistic validation;
- lexical and dictionary resources;
- Vedic and historical material;
- discourse and śāstric structures;
- modern technical terminology;
- domain evidence;
- model evaluation;
- safety, provenance, and public release.

No single “Sanskrit expert” category is adequate.

### G-46 — The uniqueness statement is too broad

The current uniqueness statement lists many integrated components. Nearly any sufficiently large integration is technically unique.

A stronger algorithmic claim would be:

> **The project tests whether a multilayer Sanskrit structural system—especially its explicit transformations, semantic-role organization, scope inheritance, default–exception structure, and lexicalized boundaries—provides a better causal mechanism for knowledge retrieval and update scope than information-equivalent universal linguistic and generic procedural representations.**

### G-47 — No explicit stopping rule for the expanded thesis

The institution should stop or narrow the architectural claim if:

- the full stack does not beat an information-equivalent universal linguistic stack;
- a generic executable grammar matches its propagation and locality;
- gains vanish under full-family and register holdouts;
- predicted structural analyses erase oracle gains;
- graph costs outweigh meaningful accuracy or data-efficiency gains;
- the model benefits only from curated terminology, not the structural organization;
- natural Sanskrit results do not reproduce clean-room gains.

---

# 6. Section-by-Section Impact on the Current Document

| Current section | What remains | What must change |
|---|---|---|
| Executive Idea | Inward hypothesis + outward evidence + reversible adaptation | Replace dhātu-led inward search with multilayer structural retrieval |
| §2 Dhātus as Internal Addresses | Roots are useful semantic/derivational indexes | Recast as one index among form, paradigm, compound, event, sense, discourse, and concept indexes |
| §3 Looking Within Itself | Explicit memory beside weights remains valid | Define a typed Sanskrit Structural Memory rather than one root-addressed store |
| §4 Reconfiguration Before Rewriting | Keep unchanged in principle | Add layer-specific scope, conflict isolation, and update permissions |
| §5 Proposed Architecture | Internal retrieval, compiler, reconciliation, and dynamic adaptation remain | Insert phonology, Sandhi, morphology, compounds, event roles, sentence/discourse, sense/register, rule graph, and canonical concept layer |
| §6 Four Types of Memory | Multi-memory architecture remains useful | Replace derivational memory with operationally partitioned structural memory |
| §7 Assimilation Compiler | Keep source preservation and claim extraction | Expand into a staged cross-layer compiler with information-loss and scope analysis |
| §8 Two-Way Realignment | Keep | Add register, lexicalization, competing analyses, and concept-without-derivation cases |
| §9 Śabda, Artha, Warrant | Keep as top-level summary | Decompose Śabda internally; add temporal and source-quality calibration |
| §10 Effective Weights | Keep as later hypothesis | Remove from first validation phase; define adapter generation and scope before use |
| §11 Semantic Inheritance | Keep default inheritance with override | Formalize through rule scope, exceptions, lexicalization, domain, register, and time |
| §12 Four Speeds | Keep | Apply different promotion thresholds to each structural memory type |
| §13 Retrieval Decision | Keep | Base retrieval decision on cross-layer uncertainty, not root confidence alone |
| §14 Retrieval-Query Generator | Keep and strengthen | Generate missing-role and missing-constraint queries from sentence/event/discourse layers |
| §15 Semantic Immune System | Keep | Add terminology capture, translation-loop contamination, school/domain disagreement, and source-faithfulness checks |
| §16 Rehearsal | Keep | Rehearse across paradigms, compounds, event paraphrases, exceptions, discourse, and registers |
| §17 Comparison with Existing Paradigms | Keep | Add universal linguistic stack and generic executable grammar as central comparators |
| §18 Deliverables | Keep most | Replace Dhātu-Addressed Memory with Multi-Index Sanskrit Structural Memory; add rule graph and scope lattice |
| §19 Risks | Keep | Add parser cascades, sense collapse, register contamination, over-attribution, and combinatorial graph growth |
| §20 Research Programme | Redesign completely | Separate structural layers before retrieval, assimilation, and plasticity |
| §21 Training Objectives | Keep joint objectives conceptually | Add objectives for segmentation, inflection, compounds, roles, discourse, rule scope, lexicalization, and cross-layer consistency |
| §22 Broader Perspectives | Keep | Avoid implying that all explicit structure is Pāṇinian; separate linguistic and epistemic traditions |
| §23 Uniqueness | Narrow and strengthen | Claim causal value of multilayer executable structure only after strong matched baselines |
| §24 Knowledge Metabolism | Keep as project metaphor | Make the metabolism operate over a multilayer structure and canonical concept/evidence layer |

---

# 7. Required Revised Architecture at a High Level

```text
INPUT
  │
  ├── Script and Unicode normalization
  ├── Canonical phonological representation
  └── Source provenance
  │
  ▼
PHONOLOGY AND SANDHI LATTICE
  │
  ▼
LEXICAL AND INFLECTIONAL LATTICE
  │
  ▼
DERIVATIONAL PROCESS GRAPH
  │
  ▼
NESTED COMPOUND HYPERGRAPH
  │
  ▼
KĀRAKA / EVENT-ROLE GRAPH
  │
  ▼
SENTENCE-CONSTRAINT AND DISCOURSE GRAPH
  │
  ▼
LEXICAL-SENSE / REGISTER / DOMAIN LAYER
  │
  ├──────────────┐
  │              │
  ▼              ▼
RULE-SCOPE     CANONICAL CONCEPT GRAPH
ENGINE           │
  │              ▼
  └────────── EVIDENCE / PROVENANCE GRAPH
                  │
                  ▼
       CROSS-LAYER RECONCILIATION
                  │
                  ▼
       MULTI-INDEX STRUCTURAL MEMORY
                  │
                  ▼
       RETRIEVAL / ROUTING / RESPONSE
                  │
                  ▼
       REVERSIBLE UPDATE TRANSACTION
```

The canonical concept graph is deliberately outside the Sanskrit structural stack. It prevents the system from confusing a term’s formation with the reality or scientific concept it denotes.

---

# 8. Priority Remediation Plan

## Priority 0 — Before any new model training

1. Rename or precisely scope the architecture so that “Pāṇinian” is not used for every Sanskrit-related component.
2. Publish a Version 1 Sanskrit Structural Stack specification.
3. Define the canonical language-independent concept and evidence schema.
4. Define the multilayer graph/hypergraph and rule-graph interchange format.
5. Replace the dhātu-addressed memory specification with multi-index structural memory.
6. Define a layer-wise update-scope lattice.
7. Redesign the evaluation baselines to include universal linguistic and generic procedural systems.
8. Pre-register falsification and stop conditions.

## Priority 1 — First research pilot

Implement only:

- script/phonological normalization;
- Sandhi lattice;
- inflection;
- derivation;
- nested compounds;
- kāraka/event roles;
- lexical senses and domain/register;
- external concept/evidence memory.

Use a frozen language model and no fast-weight rewriting.

Primary question:

> Does the multilayer Sanskrit representation improve acquisition, retrieval, propagation, and locality over information-equivalent universal and generic representations?

## Priority 2 — Scope and exception research

Add:

- rule-scope engine;
- default–exception inheritance;
- sentence compatibility;
- discourse and coreference;
- structured update-scope prediction;
- causal intervention tests.

## Priority 3 — Self-assimilation and controlled plasticity

Only after structural advantages are demonstrated, add:

- writable institutional semantic memory;
- morphology- and scope-conditioned routing;
- temporary adapters;
- rehearsal;
- governed consolidation into released model weights.

## Priority 4 — Specialist Sanskrit expansion

Add separately validated modules for:

- Vedic accent and morphology;
- recensional and oral-text variation;
- Chandas;
- kāvya and alaṅkāra;
- additional śāstric discourse systems;
- manuscript restoration and multimodal recitation.

---

# 9. Revised Uniqueness Statement

A more defensible future statement is:

> **We seek to determine whether an executable multilayer Sanskrit structural representation—spanning phonological transformation, inflection, derivation, compound hierarchy, predicate-centred semantic roles, sentence and discourse constraints, lexicalized meaning, register, and explicit rule scope—can serve as a causal substrate for knowledge acquisition, retrieval, propagation, exception handling, and update locality, outperforming information-equivalent universal linguistic, semantic-graph, generic procedural, and learned neural baselines.**

This is stronger than a broad “self-assimilating Sanskrit LLM” claim because it names the exact scientific principle under test.

---

# 10. Final Assessment

The expanded understanding of Sanskrit does **not invalidate** the self-assimilating-model concept. It reveals that the current document captures only its first layer.

The document’s most durable idea is still:

```text
internal structure proposes
external evidence grounds or corrects
controlled memory reconciles
institutional governance consolidates
```

But “internal structure” must now mean a complete, typed, uncertainty-aware structural stack—not mainly a dhātu graph.

The resulting programme is scientifically more interesting because it can test a broader principle:

> A formally organized natural language may provide not just labels for concepts, but an executable system for constraining interpretation, generating alternatives, defining inheritance, representing exceptions, and controlling where knowledge updates should and should not propagate.

It is also harder to prove. The expanded Sanskrit stack carries more information and more procedure than a generic semantic graph. Unless the baselines are information-equivalent and procedurally competitive, any apparent advantage will be inconclusive.

The next document should therefore be a **Version 2 architecture and experimental protocol**, not an immediate expansion of the current brainstorming paper.

---

# Selected Evidence Base

The following works support the need for the missing layers; the architectural conclusions in this gap analysis remain research inferences rather than results already established by these papers.

1. Amrith Krishna et al., **Word Segmentation in Sanskrit Using Path Constrained Random Walks** — Sandhi creates multiple possible segmentations, and contextual semantic validity is needed to select among them.  
   https://aclanthology.org/C16-1048/

2. Jivnesh Sandhan et al., **DepNeCTI: Dependency-based Nested Compound Type Identification for Sanskrit** — Multi-component compounds require nested structural analysis and implicit semantic-relation decoding; context improves interpretation.  
   https://aclanthology.org/2023.findings-emnlp.914/

3. Amba Kulkarni et al., **Dependency Relations for Sanskrit Parsing and Treebank** — Sanskrit parsing requires enhanced dependency relations, treatment of ellipsis and alternative morphological analysis, and factors from theories of verbal cognition.  
   https://aclanthology.org/2020.tlt-1.12/

4. Harshad Ayachit et al., **Computational Modelling of the Apatyādhikāra in Aṣṭādhyāyī** — The taddhita system exhibits hierarchy, inherited semantic scope, defaults, exceptions, and conflict resolution relevant to executable rule architecture.  
   https://aclanthology.org/2026.iscls-1.16/

5. Tapas Khanra et al., **TantraTagger: A Benchmark Dataset for Tantrayukti-Based Discourse Structure Labelling in Sanskrit Śāstra Texts** — Sanskrit śāstric discourse includes structured relations beyond sentence-level analysis.  
   https://aclanthology.org/2026.iscls-1.4/

6. Sriram Krishnan et al., **Challenges in Processing Vedic Sanskrit** — Vedic and Classical Sanskrit differ in phonology, accent, grammar, vocabulary, and usage; Vedic processing requires distinct treatment.  
   https://aclanthology.org/2025.wsc-csdh.9/

7. Anagha Pradeep et al., **Towards Building a Computational Sense Inventory from the Monier-Williams Dictionary Using Clustering Techniques** — A machine-usable Sanskrit sense inventory remains an active resource gap, particularly for polysemy and semantic consistency.  
   https://aclanthology.org/2026.iscls-1.3/

---

# Proposed Next Artifact

**Version 2 Research Architecture and Controlled Experimental Protocol** should specify:

- the bounded Sanskrit Structural Stack;
- the canonical concept model;
- the typed multilayer representation;
- the rule-scope engine;
- the update-scope lattice;
- the baseline compilers;
- the structural ladder and ablations;
- the propagation–locality benchmark;
- the data and annotation schema;
- the go/no-go criteria for self-assimilation and plasticity.
